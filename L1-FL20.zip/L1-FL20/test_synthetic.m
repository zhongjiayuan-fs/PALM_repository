 %%************************************************************************
%% run random matrix completion problems. 
%% ************************************************************************
%% n=1000,r=10, lambda=8.5
%% n=3000,r=15, lambda=12
%% n=5000,r=15, lambda=12
%% n=8000,r=15, lambda=12

clear all;

restoredefaultpath;

addpath(genpath('solvers'));

addpath(genpath('subgrad'));

addpath(genpath('PROPACKmod'));

%%

OPTIONS_AMM.maxiter = 1000;

OPTIONS_AMM.printyes = 1;

OPTIONS_AMM.tol = 5.0e-4;

OPTIONS_AMM.objtol = 5.0e-4;

OPTIONS_subGM.maxiter = 1000;

OPTIONS_subGM.printyes = 1;

OPTIONS_subGM.tol = 5.0e-4;

OPTIONS_subGM.objtol = 5.0e-4;

%% generate random a test problem

scenario = 'noisy';

errtype = 5;   %2, 5   %% 1-5

ntest = 5;    

%% ************** Initialization for test problem ******************

nr = 2000;      nc = 2000;     % nr=3000,  nr=5000

rstar = 5;   

SR = [0.1   0.15    0.2   0.25];

ns = length(SR); 

%% ***************** Initialization *********************************

AMM_matrelerr = zeros(ntest,ns);    AMM_nonsm_matrelerr = zeros(ntest,ns); 

AMM_matrank = zeros(ntest,ns);      AMM_nonsm_matrank = zeros(ntest,ns);   

AMM_mattime = zeros(ntest,ns);      AMM_nonsm_mattime = zeros(ntest,ns);    

%% ******************** main loop  **********************************************

for i = 1:length(SR)
 
        SRi  = SR(i);

    for test_iter = 1:ntest
        
        test_iter
        
        randstate =  100*i*test_iter
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        if strcmp(scenario,'noiseless')
            noiseratio = 0;
        else
            noiseratio = 0.1;  
        end
        
        fprintf('\n nr = %2.0d,   nc = %2.0d,   rank = %2.0d\n',nr,nc,rstar);
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        p = round(SRi*nr*nc);     %% number of sampled entries
        
        %% *************** to generate the true matrix ******************
        
        M.U = randn(nr,rstar);
        
        M.V = randn(nc,rstar);
        
        normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
        
        Mstar = M.U*M.V';
        
        num_sample = p;
        
    %%  *************  uniform sampling  **********************

        ind = randperm(nr*nc);

        nzidx = ind(1:p)';   zidx = ind(p+1:end)';

        bb =  Mstar(nzidx);
        
        if strcmp(scenario,'noiseless')
            xi = sparse(p,1);
            sigma = 0;
        else        
       %%  Sparse heavy tail noise
            xi = get_noise(p,bb,errtype,randstate);
     
        end
        
        bb = bb + xi;     %% case = 3    0.01*
        
        A = zeros(nr,nc);
        
        A(nzidx) = bb;
        
     %% ***************** Initialization part ************************
        
        normb = norm(bb);
        
        r = min(min(nr,nc),100);
        
        pars.normM = normM;
        
        pars.normb = normb;
        
        pars.nc = nc;   pars.nr = nr;   pars.p = p;    pars.r = r;
        
       %% ********************** to seek the starting point ****************************** 
        tstart = clock; 
       
        options = 1.0e-6;
     
        [U,dA,V] = lansvd(full(A),r,'L',options);
     
        dA = diag(dA)';
        
        max_dA = max(dA);
        
        Ustart = U(:,1:r).*dA(1:r).^(1/2);      Vstart = V(:,1:r).*dA(1:r).^(1/2);    
        
  %% ****************** test Peng's method  ************************************************************************** 
  
        OPTIONS_AMM.Lip_const = 0.85*max_dA;
  
        lambda = 12*normb;

        mu = 1.0e-8;
        
        alpha = 5;       beta = 1;
        
        [Xopt,rankXopt,Loss,obj]= PALM(Ustart,Vstart,nzidx,bb,OPTIONS_AMM,pars,lambda,alpha,beta,Mstar);

        time = etime(clock,tstart);
        
        relerr = norm(Xopt- Mstar,'fro')/normM
        
        matrank(test_iter,i) = rank(Xopt)
        
        matrelerr(test_iter,i) = relerr
        
        mattime(test_iter,i) =  time
 
%% *********************  Subgradient Method ********************************************

        lambda = 0*normb;
        
        [Xopt,rankXopt,obj]= Subgrad(Ustart,Vstart,nzidx,bb,OPTIONS_subGM,pars,lambda,mu,Mstar);

        time = etime(clock,tstart);

        relerr = norm(Xopt- Mstar,'fro')/normM
        
        matrank(test_iter,i) = rank(Xopt)
        
        matrelerr(test_iter,i) = relerr
        
        mattime(test_iter,i) =  time



    end
 
end

avrRE = mean(matrelerr)
 
avrtime = mean(mattime)  
%% *************************************************************************
