Please run the following steps in the Matlab command window:

1.  Run Matlab in the directory  L1_FL20

2. a) To generate Figure 1 in the paper, perform:

      >> test_n;

   b) To generate Figure 2 in the paper, perform:

      >> test_SR ;

 b) To generate Figure 3 in the paper, perform:

      >> test_SP ;

  c) To generate Table 1 in the paper, perform:

      >> test_test_synthetic  with  different dimensions and SR.

 
Note: The numerical results obtained on different computers may be slightly different. 