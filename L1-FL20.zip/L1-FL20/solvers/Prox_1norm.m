%% *************************************************************************
%  filename: Prox_1norm 
%
%% ************************************************************************
%% This code is to solve the following simple convex optimization 
%
%  to compute the Moreau-envelop of f(y) = ||y||_1
%
%  e_(gamma)f(g):= (0.5/gamma)*||y-g||^2+ ||y||_1 
%
%   y* = argmin{0.5*||y-g||^2+ gamma*||y||_1}, 
%
%   y* = max(0,abs(g)-gamma.*w).*sign(g);  if ||g|| is not equal to 0
%
%% *************************************************************************
% Copyright by Taoting and Shaohua Pan, 2018.3.19

function  [prox_g,Moreau_1norm] = Prox_1norm(g,gamma)

prox_g = max(0,abs(g)-gamma).*sign(g);

if nargout>=2
    
    Moreau_1norm = (0.5/gamma)*norm(g-prox_g)^2 + sum(abs(prox_g));
    
end

end