%% ********************************************************************
%  filename: PALM
%
%% **********************************************************************
%% Proximal Alternating Majorization-Minimization method for solving
%  
%  min{ 0.5||P_Omega(UV')-b-z||_F^2 + gamma*||z||_1+lambda(||U||_{2,0}+||V||_{2,0}) (*)
%  
%  in the order: z--->U--->V
%
%% **********************************************************************
%%  2020-07-15
%% *************************************************************************

function [Xopt,rankXopt,ynew,Loss,obj]= PALM(U,V,nzidx,b,OPTIONS,pars,lambda,alpha,gamma,Mstar)

if isfield(OPTIONS,'tol');        tol       = OPTIONS.tol;         end
if isfield(OPTIONS,'printyes');   printyes  = OPTIONS.printyes;    end
if isfield(OPTIONS,'maxiter');    maxiter   = OPTIONS.maxiter;     end
if isfield(OPTIONS,'Lip_const');   Lip      = OPTIONS.Lip_const;    end

nr= pars.nr;  nc = pars.nc;  r = pars.r;

LipU = Lip;   LipV = Lip;

uratio = 1.5;

lratio = 1.05;

lamb2 = 2*lambda;

if  (printyes)
    fprintf('\n *****************************************************');
    fprintf('******************************************');
    fprintf('\n ************** AMM_solver_nonsmooth  for  solving low-rank recovery  problems  ********************');
    fprintf('\n ****************************************************');
    fprintf('*******************************************');
    fprintf('\n  iter    optmeasure    rankX     nU     nV    fval     time ');
end

%% ************************* Main Loop *********************************

Uold = U;   Vold = V;

tstart = clock;

t = 1;  told = 1;

obj_list = zeros(maxiter,1);

rank_list = zeros(maxiter,1);

Xk = U*V';   yk = Xk(nzidx) -b; 

for iter = 1:maxiter
    %% ****************** to compute znew *************************

    znew = Prox_1norm(yk,1/alpha); 
   
   %% **************** accelerated step ***************************
    
    beta = (told-1)/t;
    
    beta1 = 1+beta;
    
    Ukt = beta1*U - beta*Uold;
    
    Vkt = beta1*V - beta*Vold;
    
  %% ****************** to compute Unew *************************
    
    [Loss,gradU] = funU(Ukt,V,znew,b,nzidx,alpha,pars);
    
    Utemp = (1/LipU)*(LipU*Ukt-gradU);
    
    Utemp_cnorm = LipU*sum(Utemp.*Utemp);
    
    ind = Utemp_cnorm>lamb2;     rankU = sum(ind);
    
    Unew = zeros(nr,r);
    
   if (rankU<1e-8)
  
       fprintf('\n lambda is too large, please reset it again')
        
        Xopt = 0; rankXopt = 0;
        
        return;
        
   end

   Unew(:,ind)= Utemp(:,ind); 

 %% ****************** to search the Lip-constant *******************
    
    Loss_Unew = funU(Unew,V,znew,b,nzidx,alpha,pars);
    
    diffU = Unew - Ukt;
    
    nU = 0;
    
    Lip_check = Loss + sum(dot(gradU,diffU))+ 0.5*LipU*norm(diffU,'fro')^2;
    
    Lip_org = LipU;
    
    while (Loss_Unew>Lip_check)
        
        nU = nU + 1;

        ratioU = (Loss_Unew-Lip_check)/Loss_Unew;
        
        if ratioU >= 0.8
          
            ratio = uratio;            
        else            
            ratio = lratio;            
        end
        
        LipU = (ratio)^nU*Lip_org;
        
        Utemp = (1/LipU)*(LipU*Ukt-gradU);
        
        Utemp_cnorm = LipU*sum(Utemp.*Utemp);
    
        ind = Utemp_cnorm>lamb2;     rankU = sum(ind);
    
        Unew = zeros(nr,r);          Unew(:,ind)= Utemp(:,ind); 

        Loss_Unew = funU(Unew,V,znew,b,nzidx,alpha,pars);
        
        diffU = Unew - Ukt;
        
        Lip_check = Loss + sum(dot(gradU,diffU))+ 0.5*LipU*norm(diffU,'fro')^2;
        
    end
    
 %% ****************** to compute Vnew **************************
    
    [Loss,gradV] = funV(Unew,Vkt,znew,b,nzidx,alpha,pars);
    
    Vtemp = (1/LipV)*(LipV*Vkt-gradV);

    Vtemp_cnorm = LipV*sum(Vtemp.*Vtemp);
    
    ind = Vtemp_cnorm>lamb2;    rankV = sum(ind);
    
    Vnew = zeros(nc,r);          Vnew(:,ind)= Vtemp(:,ind);
    
 %% ****************** to search the Lip-constant  *******************
    
    Loss_Vnew =  funV(Unew,Vnew,znew,b,nzidx,alpha,pars);
    
    diffV = Vnew - Vkt;
    
    Lip_check = Loss + sum(dot(gradV,diffV))+ 0.5*LipV*norm(diffV,'fro')^2;
    
    nV = 0;  Lip_org = LipV;
    
    while (Loss_Vnew>Lip_check)
        
        nV = nV + 1;
      
        ratioV = (Loss_Vnew-Lip_check)/Loss_Vnew;
        
        if ratioV >= 0.5
            
            ratio = uratio;
        else
            ratio = lratio;
        end
        
        LipV = (ratio)^nV*Lip_org;
 
        Vtemp = (1/LipV)*(LipV*Vkt - gradV);

        Vtemp_cnorm = LipV*sum(Vtemp.*Vtemp);

        ind = Vtemp_cnorm>lamb2;    rankV = sum(ind);

        Vnew = zeros(nc,r);          Vnew(:,ind)= Vtemp(:,ind);

        Loss_Vnew =  funV(Unew,Vnew,znew,b,nzidx,alpha,pars);

        diffV = Vnew - Vkt;

        Lip_check = Loss + sum(dot(gradV,diffV)) + 0.5*LipV*norm(diffV,'fro')^2;
        
    end
    
    rankX = min(rankU,rankV); 
    
    rank_list(iter) = rankX;
        
%% ******************** Optimality checking ************************
    
    [gradUnew,gradVnew,Loss,Xnew,ynew] = funUV(Unew,Vnew,znew,b,nzidx,alpha,pars);
    
    obj = Loss +  gamma*sum(abs(znew)) + lambda*(rankU + rankV);
           
    obj_list(iter) = obj;   
    
    ttime = etime(clock,tstart);
            
    err1 = norm(gradU - gradUnew + LipU*diffU,'fro');
    
    err2 = norm(gradV - gradVnew + LipV*diffV,'fro');
    
    err3 = norm(alpha*(ynew-yk));
    
    measure = (err1+err2+err3)/(1+norm(Xnew,'fro'));
    
    if (printyes && (mod(iter,1)==0||iter<=10))
       
        fprintf('\n  %2d     %3.2e      %2d        %2d     %2d        %3.4e     %3.2f',iter,measure,rankX,nU,nV,obj,ttime);
        
        relerr = norm(Xnew- Mstar,'fro')/norm(Mstar,'fro');

        %SPR = sum(abs(ynew)<= 1.0e-4*max(abs(ynew)))/length(b)
        
    end
 
        
    if (iter>=30)&&((measure<tol) ||(max(abs(obj-obj_list(iter-19:iter)))<=1.0e-4*max(1,obj)))
            
            Xopt = Xnew;
            
            rankXopt = rankX;
            
            fprintf('\n  %2d     %3.2e     %2d      %2d      %2d       %3.4e     %3.2f',iter,measure,rankX,nU,nV,obj,ttime);
            
            return;            
    end
    
    Uold = U;    Vold = V;
    
    U = Unew;    V = Vnew;
    
    yk = ynew; 
    
    told = t;
    
    t = 0.5*(1+sqrt(1+4*told^2));
    
end

if (iter==maxiter)
    
     Xopt = Xnew;
    
    rankXopt = rankX;
    
end

end

