 %% ***************************************************************
%  filename: funV_Fnorm
%
%  Compute the gradient of the loss function f
%
%  f(U,V) = 0.5*||A(UV')-b-z||^2 
%
%  gradV = [A^*(A(UV')-b-z)]'*U 
%
%% ****************************************

function [Loss,gradV] = funV(U,V,z,b,nzidx,alpha,pars)

nr = pars.nr;      nc = pars.nc; 

UVt = U*V';    

ykz = UVt(nzidx) - b - z;

Loss = 0.5*alpha*norm(ykz)^2;

if nargout>=2

  PX = zeros(nr,nc);   PX(nzidx) = ykz;

  gradV = alpha*PX'*U;

end
end
