%% *************************************************************************
%  filename: Prox_c21norm 
%
%% ************************************************************************
%% This code is to solve the following simple convex optimization 
%
%  to compute the Moreau-envelop of h(x) = lambda*||X||_{2,1}
%  
%  Y = argmin{0.5*gamma*||X-G||^2 + lambda*||X||_{2,1} }
%
%  e_(gamma)h(G):= 0.5*gamma*||Y-G||^2 + lambda*||Y||_{2,1} 
%  
%  where Yi is the ith column of the matrix Y.  
%
%   y* = argmin{0.5*||y-g||^2+ mu*||y||_2}, 
%
%   y* = max(1-mu/||g||,0)g  if ||g|| is not equal to 0
%
%% *************************************************************************
% Copyright by Taoting and Shaohua Pan, 2018.3.19

function [ProxG,Moreau_c21norm,rankPG] = Prox_c21norm(G,gamma,lambda)

if norm(G,'fro') == 0 
    
    ProxG = G;
    
    rankPG = 0;
   
else

n2 = size(G,2);

lam_gamma = lambda/gamma;

tempmu = zeros(1,n2);

norm2_col = sum(G.*G).^(1/2);

nidx = find(norm2_col>1.0e-8);

tempmu(nidx) = max(1-lam_gamma./norm2_col(nidx),0);

ProxG = G.*tempmu;

rankPG = length(nidx);

end

if nargout>=2
    
    Moreau_c21norm = 0.5*gamma*norm(G-ProxG,'fro')^2 + lambda*sum(sum(ProxG.*ProxG).^(1/2));
    
end

end