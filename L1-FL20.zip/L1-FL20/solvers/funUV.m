 %% ***************************************************************
%  filename: funUV_Fnorm
%
%  Compute the gradient of the loss function f
%
%  f(U,V) = 0.5*||UV'-Z||^2 
%
%% ****************************************

function  [gradU,gradV,Loss,UVt,yk] = funUV(U,V,z,b,nzidx,alpha,pars)

nr = pars.nr;      nc = pars.nc; 

UVt = U*V';

yk = UVt(nzidx)-b;   ykz = yk - z;

PX = zeros(nr,nc);   PX(nzidx) = ykz;

gradU = alpha*PX*V ;  

gradV = alpha*PX'*U;
    
Loss = 0.5*alpha*norm(ykz,'fro')^2;

end