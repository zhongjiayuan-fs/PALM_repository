%% ****************************************************************
%  filename:getData_snoise
%
%% ****************************************************************
%% to generate the examples with sparse noise 

function err = get_noise_SP(sp,n,b,errtype,randstate)

randn('state',double(randstate));

rand('state',double(randstate));

%% ************************ generate noise **********************

rn = randperm(n);

sn = floor(sp*n);

err = zeros(n,1);

switch errtype
    
    case 0   % the distribution sigma*N(0,1)
        
       noiseratio = 0.1;
  
       randnvec = randn(n,1);
       
       sigma = noiseratio*norm(b)/norm(randnvec);  
          
       err = sigma*randnvec;
    
    case 1  % the distribution N(0,100)
        
        err(rn(1:sn)) = 10*randn(sn,1);
        
    case 2  % the scaled Student's t-distribution with 4 degrees of freedom
        
        err(rn(1:sn)) = sqrt(2)*trnd(4,sn,1);
        
    case 3  %the Cauchy distribution with density d(u)=(1/pi)*(1/(1+u^2))
        
        temp_err = rand(sn,1);
        
        err(rn(1:sn)) = tan((temp_err-1/2)*pi);
        
        if norm(err)>1e4
        
           err = 1.0e4*err/norm(err);
        
        end
        
    case 4  % the mixture normal distribution
        
        unif = 1 + 4*rand(sn,1);
        
        err(rn(1:sn)) = unif.*randn(sn,1);
        
    case 5  % the Laplace distribution with density d(u)=0.5*exp(-|u|)
        
        temp_err = rand(sn,1)-0.5;
        
        err(rn(1:sn)) = 0 - sign(temp_err).*log(1-2*abs(temp_err));
end

end
